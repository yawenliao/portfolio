const svg = document.getElementById('svg-canvas');

window.addEventListener('resize', resizeSvg);
let boundingBox = svg.getBoundingClientRect();
width = boundingBox.width;
height = boundingBox.height;

function resizeSvg() {
    let boundingBox = svg.getBoundingClientRect();
    svg.setAttribute('viewBox', `0 0 ${boundingBox.width} ${boundingBox.height}`);
  
    for (let circle of svg.children) {
      circle.setAttribute('r', Math.min(boundingBox.width, boundingBox.height) * 0.1);
    }
  }

